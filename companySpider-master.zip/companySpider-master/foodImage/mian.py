from scrapy.cmdline import execute

execute("scrapy crawl imageList".split())
