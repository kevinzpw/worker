from scrapy import cmdline

cmdline.execute("scrapy crawl msg".split())
