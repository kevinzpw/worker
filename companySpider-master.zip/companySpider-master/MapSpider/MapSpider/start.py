from scrapy import cmdline

cmdline.execute("scrapy crawl mapSpider".split())