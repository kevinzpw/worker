#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# import os
#
# from selenium import webdriver
#
# from news.config import BASEDIR
#
#
# url = "http://www.zaobao.com/realtime/china"
#
# path = os.path.join(BASEDIR, 'drivers', 'chromedriver')
# driver = webdriver.Chrome(executable_path=path)
# driver.get(url)
# print(driver.page_source)
# driver.close()

import base64

base64.decode()