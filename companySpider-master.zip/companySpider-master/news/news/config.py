import os

BASEDIR = os.path.abspath(os.path.dirname(__file__))
STORAGE_PREFIX = ''
