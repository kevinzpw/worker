# import bs4
#
# path = 'C:\\Users\\28923\Desktop\\fhw\\fhw\\4.html'
# with open(path, 'r', encoding='utf-8', errors='ignore') as f:
#     Soup = bs4.BeautifulSoup(f.read(), 'lxml')
#     titles = Soup.select('em')
# lists = []
# for title in titles:
#     ss = title.string
#     lists.append(ss)
# print(list(set(lists)))
