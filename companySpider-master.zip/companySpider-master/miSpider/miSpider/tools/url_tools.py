
a = 3
url = 'http://home.fang.com/album/bj/s24/'

if a < 10:
    a += 1
    for i in range(a):
        print(url+str(i))