list1 = [
    'United Nations(UN)', 'Organisation des Nations Unies', 'Объединённых Наций', 'الأمم المتحدة']
name = ""
for i in list:
    name += i + ";"
print(name)
