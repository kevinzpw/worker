from scrapy import cmdline


cmdline.execute("scrapy runspider doctorList.py".split())
# cmdline.execute("scrapy crawl doctorList".split())
